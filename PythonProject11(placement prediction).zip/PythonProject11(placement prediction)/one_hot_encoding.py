import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split

# Load datase0t
df = pd.read_csv(r"C:\Users\saich\Downloads\ML\PythonProject12\placement_predict_50k Dataset (3) 1(in).csv")

# Dataset information
print("Dataset shape:", df.shape)

print("\nColumns:")
print(df.columns.tolist())


# Categorical columns
nominal_col = [
    "Gender",
    "City",
    "Stream",
    "Specialisation",
    "Hostel",
    "HistoryOfBacklogs"
]


# Split dataset into training and testing data
train_df, test_df = train_test_split(
    df,
    test_size=0.2,
    random_state=42,
    stratify=df["PlacementStatus"]
)

print("\nTraining data shape:", train_df.shape)
print("Testing data shape:", test_df.shape)

print("\nFirst 5 rows of training data:")
print(train_df.head())

print("\nFirst 5 rows of testing data:")
print(test_df.head())


# Create OneHotEncoder
ohe = OneHotEncoder(
    drop="first",
    sparse_output=False,
    handle_unknown="ignore"
)


# Fit encoder only on training data
train_ohe = ohe.fit_transform(
    train_df[nominal_col]
)

# Transform testing data using the same encoder
test_ohe = ohe.transform(
    test_df[nominal_col]
)


# Get generated column names
ohe_cols = ohe.get_feature_names_out(nominal_col)


# Convert encoded training data into DataFrame
train_ohe_df = pd.DataFrame(
    train_ohe,
    columns=ohe_cols,
    index=train_df.index
)


# Convert encoded testing data into DataFrame
test_ohe_df = pd.DataFrame(
    test_ohe,
    columns=ohe_cols,
    index=test_df.index
)


print("\nNumber of original categorical columns:",
      len(nominal_col))

print("\nGenerated One-Hot Columns:")
for col in ohe_cols:
    print(col)


print("\nFirst 5 rows of encoded training data:")
print(train_ohe_df.head())


print("\nFirst 5 rows of encoded testing data:")
print(test_ohe_df.head())